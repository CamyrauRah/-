package com.example.hearthstonereconnect

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

object ReconnectNotifications {
    const val CHANNEL = "reconnect_channel"
    fun show(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Reconnect", NotificationManager.IMPORTANCE_LOW))
        val intent = Intent(Settings.Panel.ACTION_WIFI)
        val pending = PendingIntent.getActivity(
            context, 1, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_wifi)
            .setContentTitle("Hearthstone Reconnect")
            .setContentText("Нажми Reconnect, чтобы открыть управление Wi‑Fi")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Reconnect", pending).build())
            .build()
        manager.notify(1001, notification)
    }
}
