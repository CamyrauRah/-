package com.example.hearthstonereconnect

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        fun text(s: String, size: Float = 16f) {
            layout.addView(TextView(this).apply {
                text = s; textSize = size; setPadding(0, pad / 2, 0, pad / 2)
            })
        }
        fun button(s: String, action: () -> Unit) {
            layout.addView(Button(this).apply { text = s; setOnClickListener { action() } })
        }
        text("Hearthstone Reconnect", 24f)
        text("Быстрый доступ к системной панели Wi‑Fi. Приложение не отключает сеть скрытно: Android управляет переподключением.")
        button("Включить уведомление Reconnect") { enableNotification() }
        button("Открыть настройки Wi‑Fi") { openWifiPanel() }
        button("Как добавить кнопку в шторку") {
            startActivity(Intent(Settings.ACTION_QUICK_SETTINGS_SETTINGS))
        }
        text("Добавление плитки: открой шторку полностью → Изменить (карандаш) → найди Hearthstone Reconnect → перетащи плитку вверх.")
        text("Важно: кнопка открывает системную панель Wi‑Fi. Выбери свою сеть или выключи/включи Wi‑Fi вручную. Автоматическое переключение Wi‑Fi заблокировано Android для обычных приложений.")
        setContentView(layout)
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(
            ReconnectNotifications.CHANNEL, "Reconnect", NotificationManager.IMPORTANCE_LOW
        ))
    }

    private fun enableNotification() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 42)
            return
        }
        ReconnectNotifications.show(this)
    }

    private fun openWifiPanel() = startActivity(Intent(Settings.Panel.ACTION_WIFI))
}
