package com.example.hearthstonereconnect

import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class ReconnectTileService : TileService() {
    override fun onStartListening() {
        qsTile?.apply {
            label = "Reconnect"
            state = Tile.STATE_ACTIVE
            updateTile()
        }
    }

    override fun onClick() {
        val intent = Intent(Settings.Panel.ACTION_WIFI)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startActivityAndCollapse(android.app.PendingIntent.getActivity(
                this, 2, intent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            ))
        } else {
            startActivityAndCollapse(intent)
        }
    }
}
